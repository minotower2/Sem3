#include "student.h"
int read_array(student *a, int n, const char* filename, int s);
void print_array(student *a, int n, int p);
int calc_diff(student *a, int n);
int f(int n, int s, int i);
