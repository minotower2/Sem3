#include "student.h"
#include "list_node.h"
void delete_list(list_node *);
void print_list(const list_node *, int);
io_status read_list(FILE *fp, list_node **head);
