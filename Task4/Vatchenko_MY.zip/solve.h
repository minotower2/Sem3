#include "list_node.h"
int solve1(list_node *head);
int solve2(list_node *head);
int solve3(list_node *head);
int solve4(list_node *head);
int solve5(list_node *head);
int solve6(list_node *head);
int solve7(list_node *head);
int solve8(list_node *head);
