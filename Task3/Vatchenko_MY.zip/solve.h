#include "student.h"
int solve1(student *a, int n);
int solve2(student *a, int n);
int solve3(student *a, int n);
int solve4(student *a, int n);
int solve5(student *a, int n);
int solve6(student *a, int n, student& x);
int solve7(student *a, int n, student& x);
int solve8(student *a, int n, student& x);
int solve9(student *a, int n, student& x);
int solve10(student *a, int n, student& x);
