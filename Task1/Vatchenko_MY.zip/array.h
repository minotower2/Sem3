#include "data.h"
int read_array(data *a, int n, const char* filename, int s);
void print_array(data *a, int n, int p);
int calc_diff(data *a, int n);
int f(int n, int s, int i);
